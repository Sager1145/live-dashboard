// Standalone, offline probe of selected logic from:
// Sager1145/live-dashboard @ 7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250
// OfficialEventScraper.swift. This does NOT run the app, URLSession,
// full HTML parser, official-site audit, or the user's on-device cache.
// venueCity and its tables are transcribed from the inspected production source.
// Status and cache probes isolate the production expressions.
import Foundation

struct Observation: Codable {
    let test: String
    let input: String
    let actual: String
    let desired: String
    let evidenceKind: String
}
var observations: [Observation] = []
func record(_ test: String, _ input: String, _ actual: String, _ desired: String, _ kind: String = "synthetic_input_extracted_logic") {
    observations.append(.init(test: test, input: input, actual: actual, desired: desired, evidenceKind: kind))
}
func regex(_ pattern: String, _ value: String) -> [NSTextCheckingResult] {
    guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
    return expression.matches(in: value, range: NSRange(value.startIndex..., in: value))
}
func group(_ match: NSTextCheckingResult, _ index: Int, in value: String) -> String? {
    guard index < match.numberOfRanges, let range = Range(match.range(at: index), in: value) else { return nil }
    return String(value[range])
}
let knownPrefectures = ["東京", "神奈川", "大阪", "愛知", "福岡", "石川", "兵庫", "埼玉", "千葉", "北海道", "宮城", "静岡", "京都", "広島", "沖縄", "新潟", "長野", "岡山", "熊本", "香川", "宮崎", "鹿児島", "群馬", "栃木", "茨城", "岐阜", "三重", "奈良", "滋賀", "山梨", "富山", "福井", "青森", "岩手", "秋田", "山形", "福島", "愛媛", "高知", "徳島", "山口", "鳥取", "島根", "佐賀", "長崎", "大分", "和歌山"]
let venueCityHints: [(city: String, fragments: [String])] = [
    ("東京", ["東京", "TOKYO", "Tokyo", "渋谷", "Shibuya", "新宿", "Shinjuku", "有明", "Ariake", "ARIAKE", "武道館", "立川", "TACHIKAWA", "豊洲", "羽田", "Haneda", "代々木", "Yoyogi", "両国", "国立競技場", "お台場", "池袋", "中野", "品川", "DiverCity", "日比谷", "六本木", "秋葉原", "Zepp Shinjuku", "LOVEZ", "大手町", "代官山", "duo MUSIC EXCHANGE", "O-WEST", "O-EAST", "O-Crest", "O-nest", "WWW", "LIQUIDROOM", "恵比寿", "吉祥寺", "下北沢", "赤坂", "汐留", "神田", "上野", "新木場", "蒲田", "片柳記念ホール", "豊島", "文京"]),
    ("神奈川", ["神奈川", "横浜", "Yokohama", "YOKOHAMA", "ぴあアリーナMM", "Kアリーナ", "パシフィコ", "川崎", "Kawasaki", "相模", "藤沢", "横須賀"]),
    ("大阪", ["大阪", "Osaka", "OSAKA", "京セラドーム", "インテックス", "なんば", "Namba", "Kanadevia", "万博記念公園", "梅田", "心斎橋"]),
    ("愛知", ["愛知", "名古屋", "ナゴヤ", "Nagoya", "NAGOYA", "日本ガイシ", "ポートメッセ", "バンテリンドーム", "豊田", "Aichi"]),
    ("福岡", ["福岡", "Fukuoka", "FUKUOKA", "マリンメッセ", "PayPayドーム", "BEAT STATION", "北九州"]),
    ("兵庫", ["兵庫", "神戸", "Kobe", "KOBE", "ワールド記念ホール", "GLION", "西宮"]),
    ("埼玉", ["埼玉", "さいたま", "Saitama", "SAITAMA", "大宮", "ベルーナドーム", "所沢", "メットライフ"]),
    ("千葉", ["千葉", "幕張", "Makuhari", "MAKUHARI", "舞浜", "松戸", "船橋"]),
    ("北海道", ["北海道", "札幌", "Sapporo", "SAPPORO"]),
    ("宮城", ["宮城", "仙台", "Sendai", "SENDAI"]),
    ("静岡", ["静岡", "沼津", "Numazu", "NUMAZU", "キラメッセぬまづ", "浜松", "Hamamatsu"]),
    ("石川", ["石川", "金沢", "Kanazawa"]),
    ("京都", ["京都", "Kyoto"]), ("広島", ["広島", "Hiroshima"]), ("沖縄", ["沖縄", "那覇", "Okinawa"]),
    ("新潟", ["新潟", "Niigata"]), ("長野", ["長野", "Nagano"]), ("岡山", ["岡山", "Okayama"]),
    ("熊本", ["熊本", "Kumamoto"]), ("香川", ["香川", "高松"]), ("群馬", ["群馬", "高崎"]), ("栃木", ["栃木", "宇都宮"]),
    ("台北", ["台北", "Taipei", "TAIPEI"]), ("香港", ["香港", "Hong Kong", "AsiaWorld"]),
    ("ソウル", ["ソウル", "Seoul", "SEOUL"]), ("韓国", ["韓国", "KINTEX", "Korea"]), ("上海", ["上海", "Shanghai"]),
    ("ロサンゼルス", ["Los Angeles", "ロサンゼルス", "Anaheim", "Crypto.com Arena"]),
]
func venueCity(_ venue: String) -> String {
    let prefix = venue.split(separator: "・", maxSplits: 1).first.map(String.init) ?? ""
    if knownPrefectures.contains(prefix) { return prefix }
    if let match = regex(#"(\S{2,3}?)[都道府県](?![立営])"#, venue).first, let name = group(match, 1, in: venue),
       let prefecture = knownPrefectures.first(where: { name.hasSuffix($0) }) { return prefecture }
    var best: (city: String, position: Int)?
    for hint in venueCityHints {
        for fragment in hint.fragments {
            guard let range = venue.range(of: fragment, options: [.caseInsensitive]) else { continue }
            let position = venue.distance(from: venue.startIndex, to: range.lowerBound)
            if best == nil || position > best!.position { best = (hint.city, position) }
        }
    }
    return best?.city ?? ""
}
record("venue_city_real_sample", "Kanadevia Hall", venueCity("Kanadevia Hall"), "東京", "official_sample_value_extracted_logic")
record("venue_city_control", "東京・Kanadevia Hall", venueCity("東京・Kanadevia Hall"), "東京")
record("venue_city_control_lovez", "Shibuya LOVEZ", venueCity("Shibuya LOVEZ"), "東京")

// Isolate the event-status expression; HTML.text(html) is represented by bodyText.
func status(_ bodyText: String, _ title: String, _ lastDate: String?, _ today: String) -> String {
    bodyText.contains("開催中止") || title.contains("開催中止") || title.contains("中止") ? "cancelled"
        : bodyText.contains("開催延期") || title.contains("延期") ? "postponed"
        : lastDate.map { $0 < today } == true ? "finished"
        : lastDate == nil ? "unknown" : "scheduled"
}
record("conditional_cancel_policy", "開催中止の場合は払い戻しいたします。", status("開催中止の場合は払い戻しいたします。", "テスト公演", "2026-12-01", "2026-09-23"), "scheduled")
record("cancel_negation", "開催中止ではありません。予定通り開催します。", status("開催中止ではありません。予定通り開催します。", "テスト公演", "2026-12-01", "2026-09-23"), "scheduled")
record("actual_cancellation_control", "本公演は開催中止となりました。", status("本公演は開催中止となりました。", "テスト公演", "2026-12-01", "2026-09-23"), "cancelled")

struct LoveLiveCastBlock {
    enum Scope {
        case all
        case days(Set<Int>)
        case date(year: Int?, month: Int?, day: Int)
        case stops(Set<String>)
    }
    let scope: Scope
    let names: [String]
}
func loveLivePerformers(_ blocks: [LoveLiveCastBlock], dayLabel: String, localDate: String, stop: String?) -> [String] {
    guard !blocks.isEmpty else { return [] }
    let day = regex(#"DAY\s*(\d+)"#, dayLabel).first.flatMap { group($0, 1, in: dayLabel) }.flatMap(Int.init)
    let parts = localDate.split(separator: "-").compactMap { Int($0) }
    let selected = blocks.filter { block in
        switch block.scope {
        case .all: return true
        case .days(let days): return day.map(days.contains) ?? false
        case .date(let year, let month, let dayOfMonth):
            return parts.count == 3 && parts[2] == dayOfMonth && (month ?? parts[1]) == parts[1] && (year ?? parts[0]) == parts[0]
        case .stops(let names): return stop.map(names.contains) ?? false
        }
    }
    var seen: Set<String> = []
    return (selected.isEmpty ? blocks : selected).flatMap(\.names).filter { seen.insert($0).inserted }
}
let cast = [LoveLiveCastBlock(scope: .days([1]), names: ["DAY1_ONLY"]), LoveLiveCastBlock(scope: .days([2]), names: ["DAY2_ONLY"])]
record("cast_unmatched_day", "DAY3; available cast blocks DAY1 and DAY2", loveLivePerformers(cast, dayLabel: "DAY3", localDate: "2026-11-03", stop: nil).joined(separator: ","), "")
record("cast_matched_day_control", "DAY2", loveLivePerformers(cast, dayLabel: "DAY2", localDate: "2026-11-02", stop: nil).joined(separator: ","), "DAY2_ONLY")

// Exact production fallback pattern, represented with strings rather than model structs.
let parsedRounds: [String] = []
let cachedRounds = ["old ticket deadline"]
let retainedRounds = parsedRounds.isEmpty ? cachedRounds : parsedRounds
record("empty_parse_keeps_cache", "200 HTML; no parsed rounds; cached old deadline", retainedRounds.joined(separator: ",") + "; sourceHealth=healthy", "Retain only with explicit stale/parseUnknown provenance")
let parsedNewDate = "2027-01-30"
let parsedNewStart: String? = nil
let oldStart = "2027-01-09T09:00:00Z"
record("reschedule_retains_old_timestamp", "new date=\(parsedNewDate); time not parsed", parsedNewStart ?? oldStart, "nil (or old time retained only as historical evidence)")

func canonicalURL(_ raw: String) -> String {
    guard var components = URLComponents(string: raw) else { return raw }
    components.fragment = nil
    components.host = components.host?.lowercased()
    if components.path.count > 1 { components.path = components.path.replacingOccurrences(of: #"/+$"#, with: "/", options: .regularExpression) }
    components.queryItems = components.queryItems?.sorted { ($0.name, $0.value ?? "") < ($1.name, $1.value ?? "") }
    return components.string ?? raw
}
let a = canonicalURL("https://bang-dream.com/events/bsl-taipei2026-day1/")
let b = canonicalURL("https://bang-dream.com/events/bsl-taipei2026-day2/")
record("semantic_alias_not_canonicalized", "Taipei DAY1/DAY2 alias URLs", String(a == b), "Needs separate entity-alias resolution; URL canonicalization alone cannot deduplicate", "real_sample_urls_static_identity_probe")
let encoder = JSONEncoder()
encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
let output = try encoder.encode(observations)
print(String(decoding: output, as: UTF8.self))
