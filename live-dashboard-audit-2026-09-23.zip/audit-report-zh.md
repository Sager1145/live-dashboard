# Live Dashboard：40 场样本复核与抓取链路问题报告

复核日期：2026-09-23（America/Toronto）  
仓库：Sager1145/live-dashboard  
代码固定于：`7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250`

## 结论与证据边界

当前链路需要先修正语义、作用范围、缓存与质量检测，再增加 AI。最直接的新错误是 Kanadevia Hall 被城市关键词表归为大阪；该场馆官方地址在东京，40场样本的 eleganza 使用该场馆。旧比较器不检查城市，所以旧40/40不能证明首页地点正确。[1][2][3]

本次实际做了：读取当前生产抓取代码、复核已提交40场比较结果和独立预期字段的相关部分、核对部分官网可检索内容及场馆官方页面，并在 Swift 6.2.1/Linux 单独运行抽取的逻辑。没有重新运行完整 iOS 抓取器，没有获取用户手机缓存，也没有完成两家官网合并最新40场的实时全字段验收。官网详情直接访问存在403/404或工具内部错误；搜索索引片段不能当作完整实时快照。

数据来源必须分开：下表的40/40属于仓库既有审计；回归探针属于本次离线执行；官网索引与场馆页面属于本次独立抽查。

## 一、原有40场审计到底说明什么

仓库原有清单按 BanG Dream 官方发布时间排序，41条发布记录经台北DAY1/DAY2合并为40个不同Live。修复前29/40有差异，共70个断言失败；修复后存档40/40通过。这不是“70个原子字段”，也不是两家官网合并最新40场。Love Live额外20场为五分支覆盖样本，缺少统一的首次发布时间，不可凭演出日或URL编号拼成全局发布时间排序。[2][4]

比较器实际检查标题、场次数量、部分明确的日期/会场/时区/开场开演、出演者包含关系及指定排除项、票价数组、goodsList图片URL。没有完整检查售票轮次、截止、付款、配信、限购、公告、城市和适用场次；预期文件中有ticketRoundNames，但比较器没有比较它。仓库另有票务窗口、配信期限和缓存的iOS回归测试；这里的缺口是这些字段没有在40场比较器中逐场验收，不能说整个仓库完全没有相关测试。[2][3]

### 40场逐项台账

“旧通过”仅指已提交比较文件，不是本次重新联网验证。第28项以后旧发布排名比去重排名大1。

| 去重序号 | 公演 | 仓库记录的发布时间 | 旧修复前失败断言 | 存档修复后 |
|---:|---|---|---:|---|
| 1 | [Morfonica LIVE「eleganza」](https://bang-dream.com/events/eleganza/) | 2026-09-22 | 0 | 已断言字段通过 |
| 2 | [Roselia 10th Anniversary LIVE TOUR](https://bang-dream.com/events/roselia-10th-anniversary-live-tour/) | 2026-08-30 | 1 | 已断言字段通过 |
| 3 | [WONDERLIVET 2026](https://bang-dream.com/events/wonderlivet-2026/) | 2026-08-27 | 4 | 已断言字段通过 |
| 4 | [NAKAMACHI ARALE LIVE 2026「RESONEXT」](https://bang-dream.com/events/nakamachiarale_live2026/) | 2026-08-16 | 3 | 已断言字段通过 |
| 5 | [Bushiroad Fashion Journey](https://bang-dream.com/events/bushiroad-fashion-journey/) | 2026-07-23 | 2 | 已断言字段通过 |
| 6 | [MyGO!!!!! 9th LIVE「つなぎ目の向こうに」- 神戸再景編 -](https://bang-dream.com/events/mygo_9th_hyogo/) | 2026-07-19 | 0 | 已断言字段通过 |
| 7 | [EVANESCENCE 2026 JAPAN](https://bang-dream.com/events/evanescence_avemujica/) | 2026-07-17 | 6 | 已断言字段通过 |
| 8 | [一家Dumb Rock! 1st GIG「ピース＆グルーヴ」](https://bang-dream.com/events/ikka-dumb-rock_1st/) | 2026-06-26 | 0 | 已断言字段通过 |
| 9 | [millsage LIVE 001「極夜」](https://bang-dream.com/events/millsage_1st/) | 2026-06-26 | 0 | 已断言字段通过 |
| 10 | [TVアニメ「バンドリ！ ゆめ∞みた」放送記念フリーライブ「新宿着陸計画」DAY2](https://bang-dream.com/events/yumemita_2026free/) | 2026-06-21 | 2 | 已断言字段通过 |
| 11 | [Ave Mujica 7th LIVE「Virtus」](https://bang-dream.com/events/avemujica_7th/) | 2026-06-17 | 0 | 已断言字段通过 |
| 12 | [KIMCHIKURA Fes '26](https://bang-dream.com/events/kimchikura-fes-26/) | 2026-06-04 | 2 | 已断言字段通过 |
| 13 | [BM-ECHOES FESTIVAL 2026](https://bang-dream.com/events/bm-echoes-festival-2026/) | 2026-05-31 | 1 | 已断言字段通过 |
| 14 | [BEAT AX -SUMMER EDITION 2026-](https://bang-dream.com/events/25941/) | 2026-05-22 | 1 | 已断言字段通过 |
| 15 | [ナガノアニエラフェスタ2026](https://bang-dream.com/events/anierafesta2026/) | 2026-05-15 | 3 | 已断言字段通过 |
| 16 | [FEST. INAZUMA 2026](https://bang-dream.com/events/fest-inazuma2026/) | 2026-05-08 | 5 | 已断言字段通过 |
| 17 | [BanG Dream! 13th☆LIVE DAY2 : 夢限大みゅーたいぷ「DIMENSIONAL OVERLAP」](https://bang-dream.com/events/13th-live-day2/) | 2026-05-03 | 0 | 已断言字段通过 |
| 18 | [BanG Dream! 13th☆LIVE DAY1 : Poppin'Party「Now Roading♪♪」](https://bang-dream.com/events/13th-live-day1/) | 2026-05-03 | 0 | 已断言字段通过 |
| 19 | [BanG Dream! 13th☆LIVE DAY3 : RAISE A SUILEN「EXTREME EXPRESS」](https://bang-dream.com/events/13th-live-day3/) | 2026-05-03 | 0 | 已断言字段通过 |
| 20 | [Anime Expo 2026「J-POP SOUND CAPSULE」](https://bang-dream.com/events/jsc2026/) | 2026-04-30 | 2 | 已断言字段通过 |
| 21 | [MUSIC AWARDS JAPAN WEEK SPECIAL LIVE リスアニ！LIVE on TOKYO ANIME MUSIC HIGHLIGHTS](https://bang-dream.com/events/maj_lisani2026/) | 2026-04-01 | 1 | 已断言字段通过 |
| 22 | [SUMMER SONIC 2026](https://bang-dream.com/events/summer-sonic-2026/) | 2026-03-25 | 4 | 已断言字段通过 |
| 23 | [Animelo Summer Live 2026 -Messenger-](https://bang-dream.com/events/asl2026/) | 2026-03-22 | 4 | 已断言字段通过 |
| 24 | [LuckyFes'26](https://bang-dream.com/events/luckyfes2026/) | 2026-03-10 | 1 | 已断言字段通过 |
| 25 | [Roselia「Lehre der Rose」 - Roselia 10th Anniversary Best Album「Lehre der Rose」リリース記念ライブ](https://bang-dream.com/events/lehre-der-rose/) | 2026-02-15 | 1 | 已断言字段通过 |
| 26 | [CENTRAL MUSIC & ENTERTAINMENT FESTIVAL 2026](https://bang-dream.com/events/central_music_entertainment_festival_2026/) | 2026-02-06 | 2 | 已断言字段通过 |
| 27 | [BanG Dream! Special LIVE in TAIPEI](https://bang-dream.com/events/bsl-taipei2026-day1/) | 2026-02-05 | 9 | 已断言字段通过 |
| 28 | [FLOW THE FESTIVAL 2026](https://bang-dream.com/events/flowthefestival2026/) | 2026-01-26 | 3 | 已断言字段通过 |
| 29 | [夢限大みゅーたいぷ 47都道府県制覇の旅「スーパーポジション 〜スピンアップ編〜」東京公演](https://bang-dream.com/events/yumemita_superposition_spinup_tokyo_final/) | 2026-01-23 | 1 | 已断言字段通过 |
| 30 | [夢限大みゅーたいぷ 47都道府県制覇の旅 「スーパーポジション ～ゆめんそーれ沖縄～」](https://bang-dream.com/events/yumemita_superposition_yumensore_okinawa/) | 2026-01-23 | 1 | 已断言字段通过 |
| 31 | [RAISE A SUILEN LIVE 2026「Boot IGNITION」香港公演](https://bang-dream.com/events/ras_2026/) | 2026-01-15 | 2 | 已断言字段通过 |
| 32 | [Morfonica LIVE「Movement」](https://bang-dream.com/events/morfonica_live_2026/) | 2025-12-30 | 1 | 已断言字段通过 |
| 33 | [MyGO!!!!! 9th LIVE「つなぎ目の向こうに」](https://bang-dream.com/events/mygo_9th/) | 2025-12-06 | 2 | 已断言字段通过 |
| 34 | [Poppin'Party×Roselia 合同ライブ「DREAMS GO ON」](https://bang-dream.com/events/ppp-roselia2026/) | 2025-11-22 | 0 | 已断言字段通过 |
| 35 | [MEGA VEGAS 2026](https://bang-dream.com/events/megavegas2026/) | 2025-10-10 | 2 | 已断言字段通过 |
| 36 | [リスアニ！LIVE 2026](https://bang-dream.com/events/lisani2026/) | 2025-10-03 | 1 | 已断言字段通过 |
| 37 | [夢限大みゅーたいぷ 47都道府県制覇の旅「スーパーポジション 〜スピンアップ編〜」福岡公演](https://bang-dream.com/events/yumemita_superposition_spinup/) | 2025-09-07 | 2 | 已断言字段通过 |
| 38 | [ARALE Acoustic LIVE ～Copal～](https://bang-dream.com/events/arale_acousticlive2025/) | 2025-08-16 | 1 | 已断言字段通过 |
| 39 | [MyGO!!!!!×Ave Mujica ツーマンライブ「“moment / memory”」](https://bang-dream.com/events/mygo-avemujica2026/) | 2025-08-14 | 0 | 已断言字段通过 |
| 40 | [Morfonica 5th Anniversary LIVE「Maestoso」](https://bang-dream.com/events/morfonica_live_2025/) | 2025-08-14 | 0 | 已断言字段通过 |

## 二、本次新增或确认的当前代码问题

### F01 高优先级：Kanadevia Hall 被定位到大阪

证据类型：真实样本值 + 场馆官方地址 + 当前函数离线执行。

`venueCityHints` 把 `Kanadevia` 列入大阪。`venueCity("Kanadevia Hall")` 实际返回 `大阪`。eleganza的存档场馆名恰好是这个字符串。旧存档city为空，当前代码会推断成错误值；本次没有声称看到了用户手机显示大阪。[1][5]

立即修正：删除大阪条目中的Kanadevia；先做经过官方核对的精确场馆别名映射，再使用保守地区识别。保留原场馆名、规范化场馆ID和推断来源；无法确定时不要填城市。回归加入Kanadevia Hall→东京及场馆曾用名，不要只测“城市非空”。

### F02 高优先级：整页含“開催中止”就判取消

证据类型：当前表达式 + 合成负例复现；未声称40场中存在相应实际误报。

`status` 检查整页 `HTML.text(html)` 是否包含“開催中止”。“開催中止の場合は払い戻しいたします。”（条件性退款规则）及“開催中止ではありません。”（否定）均返回cancelled。与活动无关的页尾、历史消息也可能污染状态。[5]

修正：从属于本场的公告或主标题提取状态变更事实，区分已发生/将发生的明确通知、条件句、否定句和历史撤回；保留公告时间与证据。不接受整页关键词直接覆盖状态。

### F03 高优先级：出演者未匹配到某一天，回退成所有天

证据类型：`loveLivePerformers` 函数离线执行。

该函数最后使用 `(selected.isEmpty ? blocks : selected)`。输入仅DAY1/DAY2专属出演者，却查询DAY3，会得到两天的全部出演者。真实LLDream103官网明确某出演者仅Day2，说明这种作用范围不能丢失，但本次没有证明该具体公演当前被分配错。[6]

修正需同时处理helper和调用层。仅把helper返回改成空数组不够，`parseDetail`还可能把空数组当作失败，再回退全局performers。改用显式resolution：已匹配/本场未公布/模板无法识别；已识别分日结构时禁止回退其他日名单。共同出演者可合并，但不能将不匹配当成全员。

### F04 功能缺口：多场公演售票轮次一律unconfirmed

证据类型：当前parseDetail代码。

`ticketScope`仅在一个performance时绑定该场，多场时为unconfirmed；随后统一给parsedRounds替换scope。因此正确抓到一个轮次的日期，并不等于识别出它对应哪一天/哪个城市。[5]

修正：先保留票务区块对应的站点/DAY/日期标签，逐轮解析目标；明确写全公演时关联全部场次，写个别站点时关联对应场次，真正无法判断时才unconfirmed。各类票、升级资格、配信回看、物贩都应独立作用范围。

### F05 高优先级：空解析沿用旧字段却标记healthy

证据类型：当前parseDetail代码与隔离表达式复现。

票价、售票轮次、特典、goods和streams均存在解析为空则沿用缓存的路径；最终sourceHealth仍可为healthy、publishedAt更新到now。HTTP成功、模板变化、官网移除、尚未公布被混在一起。保留旧值本身合理，但不能把它标作重新核验成功。[5]

修正：字段级状态至少分为extracted、officiallyNotPublished、explicitlyRemoved、parseUnknown、fetchFailed。未知时保留lastKnownGood并标记stale；明确撤回时从当前事实移除但保留历史；分开lastFetchedAt、lastParsedAt、lastVerifiedAt。

### F06 改期后可能把旧UTC开演时间带到新日期

证据类型：当前fallback表达式的合成复现；不是实际官网改期案例。

Performance更新localDate时，startAt/doorsAt仍用 `newValue ?? priorValue`。当缓存匹配到同一场、官网只更新日期且未解析出时间时，旧Date可能落在旧日期。复用performanceID与复用时间值是两件事。[5]

修正：localDate变化后，旧绝对时间不得无条件继承；仅在官方明确说明同一当地时刻时重建新日期上的时间，否则置未知，旧时间只留历史。

### F07 台北别名去重只在审计清单中做了，不等于生产链路通过

证据类型：存档样本选择说明 + 当前URL规范化与ID逻辑。

旧报告明确两条台北页面字节相同后手动去重；生产canonicalURL只处理fragment、host、query排序等，两个不同path仍不同。最终URL如果不重定向为同一地址，按URL生成的ID仍可能形成两张卡。此处本次只确认规范化不能去重，不声称实际生产中一定已出现重复。[2][5]

修正：建立官方ID/规范URL/已验证alias表；HTML hash只作候选合并线索，不能单独用于合并不同真实场次。测试真实index→candidate→detail→merged bundles，而不只测试人工整理后的manifest。

### F08 时间与生命周期不能仅依附整场Live

证据类型：当前设计风险，不作为已证实40场错误率。

海外公演时区和售票平台截止时区可能不同；当前eventTimeZone参与轮次解析。应为Performance、TicketRound和StreamOffer分别保留原时区与来源。演出结束一个月后仍可能有事后通販/回看/发货；保留现有一个月刷新窗口时，可对仍有活动交易/回看窗口的已结束Live添加例外，或明确显示“已冻结”。[4][5]

### F09 有数据模型不等于已经提取

当前构造bundle时，stops、ticketOffers、notices、products、goodsSessions等直接沿用缓存或空数组。首次本地抓取并不会因此获得结构化商品SKU、物贩每时段或公告事实。应把“已保存图片/原文”与“已提取商品/限制/变更”分开列示。[5]

## 三、已修正的历史问题不要再次误报为当前问题

旧报告记录LoveLive请求头403修复、巡演场馆映射修复、叠行标签与同日多场修复、重复ID引发的崩溃修复，以及goods段落去噪和streaming页签支持。本次工具访问403不证明新版本iOS仍然403。旧报告列出的测试数量也不是本次重新执行的数量。[2][4]

## 四、开源项目与模型：按当前本地iOS架构选择

| 项目 | 已核实属性 | 最适合用途 | 限制 |
|---|---|---|---|
| scinfu/SwiftSoup | Swift、HTML DOM/CSS解析、MIT | 在iOS端逐步替换自制HTML结构处理 | 不会自动理解DAY/抽选资格等语义 |
| yjl9903/eventernote | TypeScript客户端+CLI、MIT | Eventernote活动/出演者/场馆检索，补充发现与交叉检查 | 第三方数据，不能作为官方票务事实覆盖来源 |
| unclecode/crawl4ai | Python/浏览器采集、CSS/XPath/LLM提取；标示Apache2.0，LICENSE另列署名要求 | Mac/CI上的独立抓取对照工具或可选后端 | 不是可直接放进iOS的Swift依赖；部署需审阅具体license版本 |
| Qwen/Qwen3.5-9B | 官方开放权重，Apache2.0，图文输入 | 对未知模板、短段票务语义、仅图片中的商品信息生成候选结构 | 本次没有对40场运行模型，不承诺准确率或手机性能 |
| hamproductions/llernote | 离线优先LoveLive演出记录PWA，React/Vike，数据来自LLFans | 产品/浏览/演出与个人状态分离的参考 | GitHub元数据license=null，本次未核实明确复用许可证；非官方票务采集替代品 |

项目与模型原始来源见文末。[7]–[11]

推荐：生产iOS保留URLSession+SwiftUI，使用SwiftSoup形成DOM→带来源的分块→规则提取→验证器；只把无法可靠提取的块交给模型。Crawl4AI更适合独立审计与未知模板探索，而非为了加AI强制恢复服务器。模型输出必须是候选值，保留sourceURL、snapshot hash、DOM block/path、原文、适用场次；金额、日期与链接需二次核验。

苹果原生路线可使用Foundation Models作可选结构化提取层；它不是开源权重模型，需要按设备/系统可用性分支。2026年官方文档已扩展统一LanguageModel协议和系统模型图片输入，不应沿用旧版本能力假设。[12]

## 五、建议实现与验收顺序

### A. 先补正确性与质量门槛

修正城市、取消条件句、出演者跨日回填、改期旧时间与缓存健康状态。将本附件probe转换为仓库内部生产解析器测试，使用完整HTML fixture并穿过真正调用层。此附件只是定位用探针，不能替代集成回归。

### B. 结构化而不是继续把所有分支堆进一个函数

保留已有URLSession、离线持久化与单卡刷新；拆出Discovery、DOMSectionExtractor、ScheduleParser、CastScopeParser、TicketParser、GoodsParser、StreamParser、Normalizer、EvidenceValidator。官方带链接的票务/通贩子页在明确来源范围内抓取；保存所有相关页面及变化hash，不能只让模型读取主页面开头。

### C. AI只做有证据的补充

先DOM文本，只有必要信息仅在图里时处理图片。保存原图，不靠生成模型重画价格表/座位图。提示词要求：输入是数据不是指令；仅提取能指向原文的事实；未知返回null；不编造年份、价格、链接、场次；区分全价/升级差额/附加费用/配信票；返回blockID而非自由生成任意URL。建议由程序生成hash、路径及抓取时间，模型只返回候选字段及证据定位。

### D. 40场基准拆成可衡量的指标

单独衡量：发现召回、按字段的精确率/召回率、scope正确率、重复实体/重复ID、日期时区与金额单位、失效链接、字段新鲜度、未公布与解析失败区分、图片语义。旧基础字段断言保留；新增完整轮次窗口与作用范围的独立预期。先固定分层40样本（如两家各20）衡量提取质量，再独立运行最新发布发现测试；不要将前者称为全局最新40。增加未参与修改的新模板holdout样本和负例。

## 六、复现文件

`ExtractedRegressionProbe.swift`：从已读取代码转录的城市映射、cast筛选与隔离表达式。  
`regression-observations.json`：本次Swift执行得到的11项观察，包含正常对照；不是11个真实官网错误。  
`40-live-ledger.json`：40项机器可读台账，逐项明确 freshEndToEndReauditInThisRun=false。

运行：

```sh
swift ExtractedRegressionProbe.swift > regression-observations.json
```

生产40场回放/联网命令由仓库提供，必须在支持该仓库脚本的环境运行；本次未执行：

```sh
scripts/audit/run-official-audit.sh   docs/audits/2026-09-22/bangdream/unique40-manifest.json   /tmp/live-dashboard-replay.json

scripts/audit/run-official-audit.sh   docs/audits/2026-09-22/bangdream/unique40-manifest.json   /tmp/live-dashboard-live.json --live

node docs/audits/2026-09-22/bangdream/compare-normalized.mjs   /tmp/live-dashboard-live.json /tmp/comparison.json   docs/audits/2026-09-22/bangdream/unique40-expected.json
```

即使上述命令40/40，也仅说明当前比较器覆盖的断言通过；必须补齐本报告指出的缺项。

## 来源

[1] [Kanadevia官方场馆地址](https://www.kanadevia.com/english/company/corp.movie.html)
[2] [仓库原有审计报告](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/docs/audits/2026-09-22/README.md)
[3] [实际比较器](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/docs/audits/2026-09-22/bangdream/compare-normalized.mjs)
[4] [LoveLive覆盖与证据边界](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/docs/audits/2026-09-22/lovelive/README.md)
[5] [当前生产抓取代码](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/ios/Sources/LiveDashboardKit/Data/OfficialEventScraper.swift)
[6] [LLDream103官方页面（本次为搜索索引局部核对）](https://www.lovelive-anime.jp/hasunosora/live-event/live_detail.php?p=LLDream103)
[7] [SwiftSoup](https://github.com/scinfu/SwiftSoup)
[8] [Eventernote CLI/TS](https://github.com/yjl9903/eventernote)
[9] [Crawl4AI及其许可证](https://github.com/unclecode/crawl4ai)
[10] [Qwen3.5-9B官方模型卡](https://huggingface.co/Qwen/Qwen3.5-9B)
[11] [LLerNote README与GitHub元数据](https://github.com/hamproductions/llernote)
[12] [Apple 2026 Foundation Models](https://developer.apple.com/videos/play/wwdc2026/339/)
[13] [旧40场结果，非本次联网输出](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/docs/audits/2026-09-22/bangdream/unique40-comparison-live.json)
[14] [eleganza官方页面（本次为搜索索引局部核对）](https://bang-dream.com/events/eleganza/)
[15] [Roselia官方索引（本次局部核对）](https://bang-dream.com/events/?artist=roselia)
[16] [MyGO官方索引（本次局部核对）](https://bang-dream.com/events/?artist=mygo)
[17] [独立预期字段（仓库存档）](https://github.com/Sager1145/live-dashboard/blob/7d1c8c9466ab29ba1cca6a6a9f3c3120f622d250/docs/audits/2026-09-22/bangdream/unique40-expected.json)
